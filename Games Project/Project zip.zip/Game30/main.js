/*************************

Pure CSS "find game" using tabindex and :focus

See:

http://www.impressivewebs.com/using-tabindex-with-focus/

**************************/